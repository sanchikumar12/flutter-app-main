

//Subscribe Button
double subscribeSize = 15;

//Product Details
double doneIconSize = 15;

//ProfilePage

