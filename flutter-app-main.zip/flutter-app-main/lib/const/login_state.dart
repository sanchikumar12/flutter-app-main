class LoginState {
  static int waiting = 0;
  static int notLoggedIn = 1;
  static int loggedIn = 2;
  static int failed = 3;
}