enum sortBy { priceIncreasing, priceDecreasing, popularity, newest }
