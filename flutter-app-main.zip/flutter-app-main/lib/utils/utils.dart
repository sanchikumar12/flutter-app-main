String priceText(double s) {
  return s.toStringAsFixed(1);
}
