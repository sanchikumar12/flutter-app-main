package com.freshpantry.frapen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
